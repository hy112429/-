const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();

exports.main = async () => {
  const { OPENID } = cloud.getWXContext();
  if (!OPENID) return { code: 401, message: '未登录' };
  const { data: admins } = await db.collection('user').where({ openid: OPENID, role: 'admin' }).limit(1).get();
  if (!admins.length) return { code: 403, message: '需要管理员权限' };

  const userCount = (await db.collection('user').count()).total;
  const bookTotal = (await db.collection('book').count()).total;
  const pending = (await db.collection('book').where({ status: 'pending' }).count()).total;
  const onShelf = (await db.collection('book').where({ status: 'on_shelf' }).count()).total;
  const sold = (await db.collection('book').where({ status: 'sold' }).count()).total;
  let offShelf = 0;
  try {
    offShelf = (await db.collection('book').where({ status: 'off_shelf' }).count()).total;
  } catch (e) {
    offShelf = 0;
  }
  const collectCount = (await db.collection('collect').count()).total;
  const msgCount = (await db.collection('message').count()).total;
  const noticeCount = (await db.collection('notice').count()).total;
  let reportPending = 0;
  try {
    reportPending = (await db.collection('report').where({ status: 'pending' }).count()).total;
  } catch (e) {
    reportPending = 0;
  }
  let orderPending = 0;
  try {
    orderPending = (await db.collection('order').where({ status: 'pending' }).count()).total;
  } catch (e) {
    orderPending = 0;
  }

  let categoryMeta = [];
  try {
    const r = await db.collection('book_category').orderBy('sort', 'asc').get();
    if (r.data && r.data.length) {
      categoryMeta = r.data.map((c) => ({ value: c.value, label: c.label }));
    }
  } catch (e) {
    try {
      const r2 = await db.collection('book_category').limit(200).get();
      if (r2.data && r2.data.length) {
        categoryMeta = r2.data
          .slice()
          .sort((a, b) => (a.sort || 0) - (b.sort || 0))
          .map((c) => ({ value: c.value, label: c.label }));
      }
    } catch (e2) {
      /* 无集合或无数据：不按固定分类统计 */
    }
  }

  const catCounts = await Promise.all(
    categoryMeta.map((c) =>
      db
        .collection('book')
        .where({ status: 'on_shelf', category: c.value })
        .count()
        .then((r) => ({ ...c, count: r.total })),
    ),
  );
  const categoryBreakdown = catCounts.filter((x) => x.count > 0).sort((a, b) => b.count - a.count);

  let publishersCount = 0;
  try {
    const { data: rows } = await db.collection('book').field({ userId: true }).limit(2000).get();
    const set = new Set();
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].userId) set.add(rows[i].userId);
    }
    publishersCount = set.size;
  } catch (e) {
    publishersCount = 0;
  }

  let profiledUsersSample = 0;
  let profiledUsersSampleSize = 0;
  try {
    const { data: users } = await db.collection('user').limit(1000).get();
    profiledUsersSampleSize = users.length;
    profiledUsersSample = users.filter(
      (u) =>
        u.studentId &&
        String(u.studentId).trim() &&
        u.department &&
        String(u.department).trim(),
    ).length;
  } catch (e) {
    profiledUsersSample = 0;
    profiledUsersSampleSize = 0;
  }

  return {
    code: 0,
    data: {
      userCount,
      profiledUsersSample,
      profiledUsersSampleSize,
      bookTotal,
      bookByStatus: { pending, on_shelf: onShelf, off_shelf: offShelf, sold },
      categoryBreakdown,
      publishersCount,
      collectCount,
      msgCount,
      noticeCount,
      reportPending,
      orderPending,
    },
  };
};
