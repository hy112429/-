const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext();
  if (!OPENID) return { code: 401, message: '未登录' };
  const { data: admins } = await db.collection('user').where({ openid: OPENID, role: 'admin' }).limit(1).get();
  if (!admins.length) return { code: 403, message: '需要管理员权限' };

  const bookId = event.bookId;
  const action = event.action;
  const reason = (event.reason || '').trim();
  if (!bookId || !['approve', 'reject'].includes(action)) {
    return { code: 400, message: '参数错误' };
  }
  if (action === 'reject' && !reason) {
    return { code: 400, message: '下架须填写原因' };
  }

  const bookRef = db.collection('book').doc(bookId);
  const snap = await bookRef.get();
  if (!snap.data) return { code: 404, message: '书籍不存在' };

  if (action === 'approve') {
    await bookRef.update({ data: { status: 'on_shelf', reason: '' } });
  } else {
    await bookRef.update({ data: { status: 'off_shelf', reason } });
  }
  return { code: 0 };
};
