const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();

function isAlreadyExists(err) {
  const s = `${(err && err.errMsg) || ''} ${(err && err.message) || ''} ${err || ''}`;
  return /exist|已存在|重复|duplicate|already/i.test(s);
}

function isCollectionNotExistError(err) {
  const s = `${(err && err.errMsg) || ''} ${(err && err.message) || ''} ${err || ''}`;
  const code = err && (err.errCode !== undefined && err.errCode !== null ? err.errCode : err.code);
  if (code === -502005 || code === '-502005') return true;
  return /-502005|DATABASE_COLLECTION_NOT_EXIST|collection not exists?|Db or Table not exists?|ResourceNotFound/i.test(s);
}

async function ensureMessageCollection() {
  try {
    await db.createCollection('message');
  } catch (e) {
    if (!isAlreadyExists(e)) throw e;
  }
}

/** 管理员：近期私信列表（巡查 / 纠纷辅助），不含自动删改能力 */
exports.main = async () => {
  const { OPENID } = cloud.getWXContext();
  if (!OPENID) return { code: 401, message: '未登录' };
  const { data: admins } = await db.collection('user').where({ openid: OPENID, role: 'admin' }).limit(1).get();
  if (!admins.length) return { code: 403, message: '需要管理员权限' };

  let list = [];
  try {
    const r = await db.collection('message').orderBy('sendTime', 'desc').limit(100).get();
    list = r.data;
  } catch (e) {
    if (isCollectionNotExistError(e)) {
      try {
        await ensureMessageCollection();
        const r2 = await db.collection('message').orderBy('sendTime', 'desc').limit(100).get();
        list = r2.data;
      } catch (e3) {
        list = [];
      }
    } else {
      try {
        const r = await db.collection('message').limit(100).get();
        list = r.data.slice().sort((a, b) => {
          const ta = a.sendTime ? new Date(a.sendTime).getTime() : 0;
          const tb = b.sendTime ? new Date(b.sendTime).getTime() : 0;
          return tb - ta;
        });
      } catch (e2) {
        list = [];
      }
    }
  }

  return { code: 0, list };
};
