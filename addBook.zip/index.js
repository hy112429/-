const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const _ = db.command;
const { resolveActor } = require('./resolveActor.js');
exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext();
  if (!OPENID) return { code: 401, message: '未登录' };

  const ar = await resolveActor(db, _, event);
  if (ar.code !== 0 || !ar.me) return { code: ar.code || 401, message: ar.message || '请先登录' };
  const me = ar.me;
  if (me.disabled === true) return { code: 403, message: '账号已被限制，无法发布' };
  if (!me.studentId || !me.department) {
    return { code: 400, message: '请先完善校园信息（学号、院系）' };
  }

  const b = event.book || {};
  const title = (b.title || '').trim();
  const author = (b.author || '').trim();
  const price = Number(b.price);
  const images = Array.isArray(b.images) ? b.images.slice(0, 3) : [];
  const category = (b.category || '').trim();
  const quality = (b.quality || '').trim();
  const remark = (b.remark || '').trim();
  const rawPhoneInput = String(b.contactPhone != null ? b.contactPhone : '').trim();
  const phoneDigitsForm = rawPhoneInput.replace(/\D/g, '');
  const phoneDigitsProfile = String(me.phone != null ? me.phone : '')
    .trim()
    .replace(/\D/g, '');
  if (rawPhoneInput && phoneDigitsForm.length < 6) {
    return { code: 400, message: '联系电话至少 6 位数字，或留空使用个人信息中的号码' };
  }
  if (phoneDigitsForm.length > 15) {
    return { code: 400, message: '联系电话过长' };
  }
  const contactPhone =
    (phoneDigitsForm.length >= 6 ? phoneDigitsForm : '') || phoneDigitsProfile || '';

  if (!title) return { code: 400, message: '请填写书名' };
  if (!category || !quality) return { code: 400, message: '请选择分类与成色' };
  try {
    const cnt = await db.collection('book_category').where({ value: category }).count();
    if ((cnt.total || 0) === 0) {
      return { code: 400, message: '所选分类无效或已删除，请下拉刷新后重新选择；若尚无分类请联系管理员在后台添加' };
    }
  } catch (e) {
    return {
      code: 400,
      message: '书籍分类未就绪，请管理员部署 categoryManage / initDb 并在「书籍分类」中添加分类',
    };
  }
  if (!(price >= 0 && price <= 200)) return { code: 400, message: '价格须在 0～200 元' };
  if (!images.length) return { code: 400, message: '请至少上传 1 张图片（最多 3 张）' };

  const dup = await db.collection('book').where({ userId: me._id, title }).get();
  const hasDup = dup.data.some(
    (x) => (x.author || '') === author && ['pending', 'on_shelf'].includes(x.status),
  );
  if (hasDup) return { code: 400, message: '不可重复发布同款书籍（书名+作者）' };

  const add = await db.collection('book').add({
    data: {
      userId: me._id,
      title,
      author: author || '',
      price,
      category,
      quality,
      images,
      remark,
      /** 优先发布页填写，否则为个人资料中的号码 */
      contactPhone: contactPhone || '',
      /** 普通用户待管理员审核；管理员发布可直接上架 */
      status: me.role === 'admin' ? 'on_shelf' : 'pending',
      reason: '',
      publishTime: db.serverDate(),
    },
  });
  const needAudit = me.role !== 'admin';
  return {
    code: 0,
    bookId: add._id,
    status: needAudit ? 'pending' : 'on_shelf',
    needAudit,
  };
};
