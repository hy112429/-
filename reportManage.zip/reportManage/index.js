const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const _ = db.command;
const { resolveActor } = require('./resolveActor.js');

function isAlreadyExists(err) {
  const s = `${(err && err.errMsg) || ''} ${(err && err.message) || ''} ${err || ''}`;
  return /exist|已存在|重复|duplicate|already/i.test(s);
}

function isCollectionNotExistError(err) {
  const code = err && (err.errCode !== undefined && err.errCode !== null ? err.errCode : err.code);
  if (code === -502005 || code === '-502005') return true;
  const s = `${(err && err.errMsg) || ''} ${(err && err.message) || ''} ${(err && err.errDetails) || ''}`;
  return /-502005|DATABASE_COLLECTION_NOT_EXIST|collection not exists?|Db or Table not exists?|ResourceNotFound/i.test(
    s,
  );
}

async function ensureReportCollection() {
  try {
    await db.createCollection('report');
  } catch (e) {
    if (!isAlreadyExists(e)) throw e;
  }
}

async function fetchReportList(depth = 0) {
  if (depth > 3) throw new Error('report 集合初始化重试过多');
  const col = db.collection('report');
  try {
    const r = await col.orderBy('createTime', 'desc').limit(80).get();
    return r.data;
  } catch (e) {
    if (isCollectionNotExistError(e)) {
      await ensureReportCollection();
      return fetchReportList(depth + 1);
    }
    try {
      const r = await col.limit(80).get();
      return r.data.slice().sort((a, b) => {
        const ta = a.createTime ? new Date(a.createTime).getTime() : 0;
        const tb = b.createTime ? new Date(b.createTime).getTime() : 0;
        return tb - ta;
      });
    } catch (e2) {
      if (isCollectionNotExistError(e2)) {
        await ensureReportCollection();
        return fetchReportList(depth + 1);
      }
      throw e2;
    }
  }
}

async function getUserByOpenid(openid) {
  const { data } = await db.collection('user').where({ openid }).limit(1).get();
  return data[0] || null;
}

async function requireAdmin(openid) {
  const u = await getUserByOpenid(openid);
  if (!u || u.role !== 'admin') return null;
  return u;
}

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext();
  if (!OPENID) return { code: 401, message: '未登录' };
  const action = event.action;

  if (action === 'submit') {
    const ar = await resolveActor(db, _, event);
    if (ar.code !== 0 || !ar.me) return { code: ar.code || 401, message: ar.message || '用户不存在' };
    const me = ar.me;
    if (me.disabled === true) return { code: 403, message: '账号已被限制' };
    const bookId = event.bookId;
    const reason = (event.reason || '').trim();
    if (!bookId || !reason) return { code: 400, message: '请填写举报原因' };
    const bookSnap = await db.collection('book').doc(bookId).get();
    const book = bookSnap.data;
    if (!book) return { code: 404, message: '书籍不存在' };
    if (book.userId === me._id) return { code: 400, message: '不能举报自己的书籍' };
    try {
      await ensureReportCollection();
    } catch (e) {
      return {
        code: 500,
        message: `report 集合不可用：${(e && e.errMsg) || (e && e.message) || String(e)}`,
      };
    }
    await db.collection('report').add({
      data: {
        reporterId: me._id,
        targetUserId: book.userId,
        bookId,
        reason,
        status: 'pending',
        createTime: db.serverDate(),
      },
    });
    return { code: 0 };
  }

  if (action === 'list') {
    const admin = await requireAdmin(OPENID);
    if (!admin) return { code: 403, message: '需要管理员' };
    try {
      const data = await fetchReportList();
      return { code: 0, list: data };
    } catch (e) {
      return {
        code: 1,
        message: (e && e.errMsg) || (e && e.message) || String(e),
        list: [],
      };
    }
  }

  if (action === 'resolve') {
    const admin = await requireAdmin(OPENID);
    if (!admin) return { code: 403, message: '需要管理员' };
    const id = event.id;
    if (!id) return { code: 400, message: '缺少 id' };
    try {
      await ensureReportCollection();
    } catch (e) {
      return {
        code: 500,
        message: `report 集合不可用：${(e && e.errMsg) || (e && e.message) || String(e)}`,
      };
    }
    await db.collection('report').doc(id).update({ data: { status: 'done', handleTime: db.serverDate() } });
    return { code: 0 };
  }

  return { code: 400, message: '未知 action' };
};
