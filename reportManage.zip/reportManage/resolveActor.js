const cloud = require('wx-server-sdk');

function stripLocalSecrets(u) {
  if (!u) return u;
  const o = { ...u };
  delete o.passwordHash;
  return o;
}

/**
 * 解析当前操作者：① __sessionToken；② 当前微信下未过期的 auth_session → local_user；③ user（openid）
 */
async function resolveActor(db, _, event) {
  const { OPENID } = cloud.getWXContext();
  if (!OPENID) {
    return { code: 401, message: '未登录', me: null };
  }
  const token = event && event.__sessionToken ? String(event.__sessionToken).trim() : '';
  if (token) {
    const now = new Date();
    let sess;
    try {
      const r = await db.collection('auth_session').where({ token, expireAt: _.gt(now) }).limit(1).get();
      sess = r.data || [];
    } catch (e) {
      return { code: 401, message: '账号登录已过期，请重新登录', me: null };
    }
    if (!sess.length) {
      return { code: 401, message: '账号登录已过期，请重新登录', me: null };
    }
    const s = sess[0];
    if (String(s.wxOpenid) !== String(OPENID)) {
      return { code: 403, message: '会话无效', me: null };
    }
    let lu;
    try {
      lu = await db.collection('local_user').doc(String(s.localUserId)).get();
    } catch (e) {
      return { code: 401, message: '账号不存在', me: null };
    }
    if (!lu.data) return { code: 401, message: '账号不存在', me: null };
    if (lu.data.disabled === true) {
      return { code: 403, message: '账号已被限制', me: null };
    }
    const me = stripLocalSecrets(lu.data);
    me._actorKind = 'local';
    me._balanceCol = 'local_user';
    return { code: 0, me };
  }

  /**
   * 未传 __sessionToken 时：若当前微信下仍有未过期的 auth_session，则视为本地账号。
   * 避免个别调用链未合并 token 时误用 user（openid）导致余额为 0、与钱包页不一致。
   */
  const now2 = new Date();
  let sessRows = [];
  try {
    const sr = await db
      .collection('auth_session')
      .where({ wxOpenid: OPENID, expireAt: _.gt(now2) })
      .limit(30)
      .get();
    sessRows = sr.data || [];
  } catch (e) {
    sessRows = [];
  }
  if (sessRows.length) {
    sessRows.sort((a, b) => {
      const ta = a.createTime ? new Date(a.createTime).getTime() : 0;
      const tb = b.createTime ? new Date(b.createTime).getTime() : 0;
      return tb - ta;
    });
    const s0 = sessRows[0];
    let lu0;
    try {
      lu0 = await db.collection('local_user').doc(String(s0.localUserId)).get();
    } catch (e) {
      lu0 = { data: null };
    }
    if (lu0.data) {
      if (lu0.data.disabled === true) {
        return { code: 403, message: '账号已被限制', me: null };
      }
      const me0 = stripLocalSecrets(lu0.data);
      me0._actorKind = 'local';
      me0._balanceCol = 'local_user';
      return { code: 0, me: me0 };
    }
  }

  const { data } = await db.collection('user').where({ openid: OPENID }).limit(1).get();
  if (!data.length) {
    return { code: 401, message: '请先登录', me: null };
  }
  const me = { ...data[0] };
  me._actorKind = 'wechat';
  me._balanceCol = 'user';
  if (me.disabled === true) {
    return { code: 403, message: '账号已被限制', me: null };
  }
  return { code: 0, me };
}

function actorBalanceCollection(me) {
  return me && me._balanceCol ? me._balanceCol : 'user';
}

/** 书籍卖家等：userId 可能是微信用户或独立账号 */
async function fetchUserProfileById(db, id) {
  if (!id) return null;
  const sid = String(id);
  try {
    const u = await db.collection('user').doc(sid).get();
    if (u.data) return u.data;
  } catch (e) {
    /* */
  }
  try {
    const l = await db.collection('local_user').doc(sid).get();
    if (l.data) return stripLocalSecrets(l.data);
  } catch (e) {
    /* */
  }
  return null;
}

/** 给订单退款/入账用：按 _id 判断更新 local_user 或 user */
async function incBalanceByUserId(db, _, userId, deltaFen) {
  const id = String(userId);
  let colName = 'user';
  try {
    const l = await db.collection('local_user').doc(id).get();
    if (l.data) colName = 'local_user';
  } catch (e) {
    /* */
  }
  await db.collection(colName).doc(id).update({ data: { balanceFen: _.inc(deltaFen) } });
}

module.exports = {
  resolveActor,
  actorBalanceCollection,
  fetchUserProfileById,
  stripLocalSecrets,
  incBalanceByUserId,
};
