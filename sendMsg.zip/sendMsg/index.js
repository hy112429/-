const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const _ = db.command;
const { resolveActor } = require('./resolveActor.js');

function isAlreadyExists(err) {
  const s = `${(err && err.errMsg) || ''} ${(err && err.message) || ''} ${err || ''}`;
  return /exist|已存在|重复|duplicate|already/i.test(s);
}

async function ensureMessageCollection() {
  try {
    await db.createCollection('message');
  } catch (e) {
    if (!isAlreadyExists(e)) throw e;
  }
}

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext();
  if (!OPENID) return { code: 401, message: '未登录' };

  const ar = await resolveActor(db, _, event);
  if (ar.code !== 0 || !ar.me) return { code: ar.code || 401, message: ar.message || '未登录' };
  const me = ar.me;
  if (me.disabled === true) return { code: 403, message: '账号已被限制' };

  const action = (event && event.action) || 'send';
  const myId = String(me._id);

  /** 客户端读 message 常受数据库权限限制（fromId/toId 为业务 _id 非 openid），改由云函数拉取 */
  if (action === 'listForBook') {
    const bookId = String((event && event.bookId) || '').trim();
    const peerId = String((event && event.peerId) || '').trim();
    if (!bookId || !peerId) return { code: 400, message: '缺少 bookId 或 peerId' };
    if (peerId === myId) return { code: 400, message: '参数无效' };
    try {
      await ensureMessageCollection();
    } catch (e) {
      return {
        code: 500,
        message: `message 集合不可用：${(e && e.errMsg) || (e && e.message) || String(e)}`,
      };
    }
    let rows = [];
    try {
      const r = await db.collection('message').where({ bookId }).limit(200).get();
      rows = r.data || [];
    } catch (e) {
      return {
        code: 500,
        message: `读取消息失败：${(e && e.errMsg) || (e && e.message) || String(e)}`,
      };
    }
    const filtered = rows.filter(
      (m) =>
        (String(m.fromId) === myId && String(m.toId) === peerId) ||
        (String(m.fromId) === peerId && String(m.toId) === myId),
    );
    filtered.sort((a, b) => {
      const ta = a.sendTime ? new Date(a.sendTime).getTime() : 0;
      const tb = b.sendTime ? new Date(b.sendTime).getTime() : 0;
      return ta - tb;
    });
    return { code: 0, list: filtered };
  }

  const toId = String((event && event.toId) || '').trim();
  const bookId = String((event && event.bookId) || '').trim();
  const content = (event.content || '').trim();
  if (!toId || !bookId || !content) return { code: 400, message: '缺少参数' };
  if (toId === myId) return { code: 400, message: '不能给自己发私信' };

  try {
    await ensureMessageCollection();
  } catch (e) {
    return {
      code: 500,
      message: `message 集合不可用：${(e && e.errMsg) || (e && e.message) || String(e)}`,
    };
  }

  await db.collection('message').add({
    data: {
      fromId: myId,
      toId,
      bookId,
      content,
      isRead: false,
      sendTime: db.serverDate(),
    },
  });
  return { code: 0 };
};
