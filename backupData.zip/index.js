const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();

/**
 * 轻量备份：各集合条数写入 backup_log。
 * - 管理员在后台点击：需 OPENID + admin。
 * - 定时触发器：无 OPENID，且 event.Type === 'Timer'（客户端无法伪造出无 OPENID 的调用）。
 * 全量文档导出请在云开发控制台使用「数据库导出」。
 */
exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext();
  const isTimerInvoke = !OPENID && event && event.Type === 'Timer';

  if (!isTimerInvoke) {
    if (!OPENID) return { code: 401, message: '未登录' };
    const { data: admins } = await db.collection('user').where({ openid: OPENID, role: 'admin' }).limit(1).get();
    if (!admins.length) return { code: 403, message: '需要管理员权限' };
  }

  const names = ['user', 'book', 'collect', 'message', 'notice'];
  const counts = {};
  for (let i = 0; i < names.length; i++) {
    const n = names[i];
    try {
      counts[n] = (await db.collection(n).count()).total;
    } catch (e) {
      counts[n] = -1;
    }
  }
  const extra = ['report', 'order', 'book_category', 'backup_log'];
  for (let j = 0; j < extra.length; j++) {
    const n = extra[j];
    try {
      counts[n] = (await db.collection(n).count()).total;
    } catch (e) {
      counts[n] = 0;
    }
  }

  await db.collection('backup_log').add({
    data: {
      time: db.serverDate(),
      counts,
      source: isTimerInvoke ? 'timer' : 'admin',
      note: isTimerInvoke
        ? '定时任务：条数快照（非全量）'
        : '管理员手动：条数快照；全量请控制台导出',
    },
  });
  return { code: 0, counts, source: isTimerInvoke ? 'timer' : 'admin' };
};
