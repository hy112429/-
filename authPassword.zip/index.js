const crypto = require('crypto');
const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const _ = db.command;
const { resolveActor, stripLocalSecrets } = require('./resolveActor.js');

const PBKDF2_ITER = 150000;
const SESSION_MS = 30 * 24 * 3600 * 1000;

function hashPassword(plain) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(plain, salt, PBKDF2_ITER, 32, 'sha256').toString('hex');
  return `pbkdf2$${PBKDF2_ITER}$${salt}$${hash}`;
}

function verifyPassword(plain, stored) {
  if (!stored || typeof stored !== 'string') return false;
  const parts = stored.split('$');
  if (parts.length !== 4 || parts[0] !== 'pbkdf2') return false;
  const iter = parseInt(parts[1], 10);
  if (!Number.isFinite(iter) || iter < 1000) return false;
  const salt = parts[2];
  const expectedHex = parts[3];
  if (!/^[0-9a-f]+$/i.test(expectedHex) || expectedHex.length !== 64) return false;
  const h2 = crypto.pbkdf2Sync(plain, salt, iter, 32, 'sha256').toString('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(expectedHex, 'hex'), Buffer.from(h2, 'hex'));
  } catch (e) {
    return false;
  }
}

function validateUsername(u) {
  const s = String(u || '').trim();
  if (s.length < 3 || s.length > 20) return { ok: false, msg: '账号名为 3～20 个字符' };
  if (!/^[a-zA-Z0-9_\u4e00-\u9fa5]+$/.test(s)) return { ok: false, msg: '账号名仅支持字母、数字、下划线与中文' };
  return { ok: true, value: s };
}

function validatePassword(p) {
  const s = String(p || '');
  if (s.length < 6 || s.length > 32) return { ok: false, msg: '密码长度为 6～32 位' };
  return { ok: true, value: s };
}

function isAlreadyExists(err) {
  const s = `${(err && err.errMsg) || ''} ${(err && err.message) || ''} ${err || ''}`;
  return /exist|已存在|重复|duplicate|already/i.test(s);
}

async function ensureCols() {
  for (let i = 0; i < 2; i++) {
    const name = i === 0 ? 'local_user' : 'auth_session';
    try {
      await db.createCollection(name);
    } catch (e) {
      if (!isAlreadyExists(e)) throw e;
    }
  }
}

function packUserForClient(me) {
  const u = stripLocalSecrets({ ...me });
  delete u._actorKind;
  delete u._balanceCol;
  const bf = u.balanceFen;
  u.balanceFen = Math.max(0, Math.round(Number(bf != null ? bf : 0) || 0));
  return u;
}

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext();
  if (!OPENID) return { code: 401, message: '未登录（无微信身份）' };

  const action = event && event.action;

  try {
    await ensureCols();
  } catch (e) {
    return { code: 500, message: (e && e.errMsg) || (e && e.message) || String(e) };
  }

  if (action === 'ping') {
    const ar = await resolveActor(db, _, event);
    if (ar.code !== 0 || !ar.me) return { code: ar.code || 401, message: ar.message || '未登录' };
    return { code: 0, user: packUserForClient(ar.me), authKind: ar.me._actorKind };
  }

  if (action === 'logout') {
    const token = event && event.__sessionToken ? String(event.__sessionToken).trim() : '';
    if (!token) return { code: 400, message: '缺少会话' };
    try {
      const r = await db.collection('auth_session').where({ token, wxOpenid: OPENID }).limit(20).get();
      for (let i = 0; i < r.data.length; i++) {
        await db.collection('auth_session').doc(r.data[i]._id).remove();
      }
    } catch (e) {
      /* */
    }
    return { code: 0 };
  }

  if (action === 'profile') {
    const ar = await resolveActor(db, _, event);
    if (ar.code !== 0 || !ar.me) return { code: ar.code || 401, message: ar.message || '未登录' };
    if (ar.me._actorKind !== 'local') {
      return { code: 400, message: '当前为微信账号，请在「个人信息」使用原保存流程' };
    }
    const { studentId, department, name, phone, avatar } = event;
    await db.collection('local_user').doc(ar.me._id).update({
      data: {
        studentId: studentId != null ? String(studentId).trim() : '',
        department: department != null ? String(department).trim() : '',
        name: name != null ? String(name).trim() : '',
        phone: phone != null ? String(phone).trim() : '',
        avatar: avatar != null ? String(avatar) : '',
      },
    });
    const fresh = await db.collection('local_user').doc(ar.me._id).get();
    return { code: 0, user: packUserForClient(fresh.data) };
  }

  if (action === 'register') {
    const vu = validateUsername(event.username);
    const vp = validatePassword(event.password);
    if (!vu.ok) return { code: 400, message: vu.msg };
    if (!vp.ok) return { code: 400, message: vp.msg };

    const existed = await db.collection('local_user').where({ username: vu.value }).limit(1).get();
    if (existed.data.length) {
      return { code: 400, message: '该账号名已被注册' };
    }

    const ph = hashPassword(vp.value);
    const add = await db.collection('local_user').add({
      data: {
        username: vu.value,
        passwordHash: ph,
        studentId: '',
        department: '',
        name: '',
        phone: '',
        avatar: '',
        role: 'user',
        disabled: false,
        balanceFen: 0,
        createTime: db.serverDate(),
      },
    });
    const doc = await db.collection('local_user').doc(add._id).get();
    const u0 = doc.data;

    const token = crypto.randomBytes(32).toString('hex');
    const expireAt = new Date(Date.now() + SESSION_MS);
    await db.collection('auth_session').add({
      data: {
        token,
        localUserId: u0._id,
        wxOpenid: OPENID,
        expireAt,
        createTime: db.serverDate(),
      },
    });

    return { code: 0, user: packUserForClient(u0), sessionToken: token, authKind: 'local' };
  }

  if (action === 'login') {
    const vu = validateUsername(event.username);
    const vp = validatePassword(event.password);
    if (!vu.ok) return { code: 400, message: vu.msg };
    if (!vp.ok) return { code: 400, message: vp.msg };

    const { data } = await db.collection('local_user').where({ username: vu.value }).limit(1).get();
    if (!data.length) return { code: 401, message: '账号或密码错误' };
    const u = data[0];
    if (!u.passwordHash || !verifyPassword(vp.value, u.passwordHash)) {
      return { code: 401, message: '账号或密码错误' };
    }
    if (u.disabled === true) return { code: 403, message: '账号已被限制' };

    try {
      const old = await db.collection('auth_session').where({ wxOpenid: OPENID }).limit(50).get();
      for (let i = 0; i < old.data.length; i++) {
        await db.collection('auth_session').doc(old.data[i]._id).remove();
      }
    } catch (e) {
      /* */
    }

    const token = crypto.randomBytes(32).toString('hex');
    const expireAt = new Date(Date.now() + SESSION_MS);
    await db.collection('auth_session').add({
      data: {
        token,
        localUserId: u._id,
        wxOpenid: OPENID,
        expireAt,
        createTime: db.serverDate(),
      },
    });

    return { code: 0, user: packUserForClient(u), sessionToken: token, authKind: 'local' };
  }

  return { code: 400, message: '未知 action' };
};
